package de.telran.hometask6;

import java.util.Scanner;

public class Task1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Напишите первое мслово с чётным колличеством символов:");
        String myStr1 = scanner.next();
        int myLength1 = myStr1.length();


        System.out.print(" Напишите второе слово с чётным колличеством символов:");
        String myStr2 = scanner.next();
        int myLength2 = myStr1.length();
        int myHalfStr1 = myLength1 / 2;
        int myHalfStr2 = myLength2 / 2;
        System.out.println(" Слово состоящее из половинок первого и второго слова:"+myStr1.substring(myHalfStr1) + myHalfStr2);
    }

}





//Введите 2 слова, воспользуйтесь сканером, состоящие из четного количества букв (проверьте количество букв в слове).
  //      Нужно получить слово, состоящее из первой половины первого слова и второй половины второго слова. распечатать на консоль.


