package hometask1;

public class Task2 {
    public static void main(String[] args) {
       Integer myInt = 89;
        myInt = 89;
        System.out.println(myInt);

        byte myByte = 4;
        short mySchort = 56;
        long myLong = 12121;
        float myFloat = 47333436;
        double myDouble = 4.355453532;
        char symbol = 'G';
        System.out.println("myByte = "+myByte);
        System.out.println("mySchort = "+mySchort);
        System.out.println("myLong = "+myLong);
        System.out.println("myFloat = "+myFloat);
        System.out.println("myDouble = "+myDouble);
        System.out.println("symbol = "+symbol);

    }
}



