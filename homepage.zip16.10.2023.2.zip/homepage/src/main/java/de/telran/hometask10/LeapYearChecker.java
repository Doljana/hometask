package de.telran.hometask10;

import java.util.Scanner;

public class LeapYearChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println(" Введите год");
        int year = scanner.nextInt();

        // Реализуйте программу, которая попросит пользователя ввести год и напечатать этот год.
        // Метод isLeap проверяет високосный год или нет.


        if (isLeap(year)) {

            System.out.println("  это високосный год." + year);

        } else {
            System.out.println(year + " - это не високосный год.");
        }

    }


    public static boolean isLeap(int year) {

        return (year % 4 == 0);
    }
}