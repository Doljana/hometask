package de.telran.Hometask9;

import java.util.Scanner;

public class Task1 {
    public static <Scaner> void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        double numberSystem = scanner.nextDouble();
        System.out.println("Введите первое число:" +numberSystem);
        double numberSystem2 = scanner.nextDouble();
        System.out.println( "Введите второе число :"+ numberSystem2);

        if (numberSystem <= numberSystem2) {
            System.out.println("Первое число ближе к 10:");

        }
        else {
            System.out.println("Второе число ближе к 10:");

        }

       // Создать программу, выводящую на экран ближайшее к 10 из двух чисел, записанных в переменные m и n.
               // Числа могут быть, как целочисленные, так и дробные.

       // Например :
       // ввод : m=10.5, n=10.45
       // вывод: Число 10.45 ближе к 10.








    }
}
