package de.telran.Hometask9;

import java.util.Random;

public class Workday {
    public static void main(String[] args) {

        Random rand = new Random();

        // Генерируем случайное количество секунд от 0 до 28800
        int n = rand.nextInt(28801);

        // Выводим количество секунд
        System.out.println("Осталось " + n + " секунд");

        // Вычисляем количество полных часов
        int hoursRemaining = n / 3600;

        // Выводим соответствующую фразу
        if (hoursRemaining > 7) {
            System.out.println("Осталось " + hoursRemaining + " часов");
        } else if (hoursRemaining == 1) {
            System.out.println("Остался 1 час");
        } else if (hoursRemaining > 0) {
            System.out.println("Осталось " + hoursRemaining + " часа");
        } else {
            System.out.println("Осталось менее часа");
        }
    }
}







