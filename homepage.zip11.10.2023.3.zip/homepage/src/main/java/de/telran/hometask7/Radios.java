package de.telran.hometask7;

public class Radios {
    public static void main(String[] args) {

      double pizza1 = 24;
        double pizza2 = 28;

        double area = Math.PI * Math.pow(pizza1 /2,2);

        double area2= Math.PI * Math.pow(pizza2 /2,2);

        double difference = area2-area;
        double call = 40* difference;





        System.out.println( "Будет лишних каллорий если сьесть пиццу 28 см:");

        //Напишите программу, которая вычисляет, сколько лишних калорий будет, если вместо пиццы диаметром 24 см вы купите пиццу диаметром 28 см.
        // Чтобы решить эту проблему, предположим, что каждый квадратный сантиметр пиццы содержит 40 калорий.


    }




     }





//double radius = 24 * Math.PI * getRadios();
//
//double radius2 = 28 * Math.PI * getR double area = Math.PI * (radius * radius);adios();
//double area2= Math.PI * (radius * radius);
//System.out.println("Площадь 1 пиццы равнва" + area);
//System.out.println("Площадь 2 пиццы равнва" + area2);


//}
//}
