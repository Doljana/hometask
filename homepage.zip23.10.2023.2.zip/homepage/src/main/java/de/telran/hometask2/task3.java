package de.telran.hometask2;

public class task3 {
    public static void main(String[] args) {
String str1 = "Самый лучший день в Java" ;
System .out.println("Самый лучший день в Java");

    }
}













//Распечатать пред-последний символ строки. Используем метод String.charAt().//
//Проверить, содержит ли ваша строка подстроку “Java”. Используем метод String.contains().//
//Вырезать строку Java c помощью метода String.substring().//
//Заменить все символы “а” на “о”. //
//Преобразуйте строку к верхнему регистру.//
//Преобразуйте строку к нижнему регистру.//