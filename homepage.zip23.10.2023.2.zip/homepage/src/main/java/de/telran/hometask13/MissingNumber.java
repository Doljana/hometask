package de.telran.hometask13;

public class MissingNumber {
    public static void main(String[] args) {
       // Дан массив размера  n-1, содержащий только различные целые числа в диапазоне от 1 до n . Найдите недостающий элемент.
        int[] arr1 = {1, 2, 3, 5};
        int missing1 = findMissingNumber(arr1);
        System.out.println("Missing number in arr1: " + missing1);

        int[] arr2 = {6, 1, 2, 8, 3, 4, 7, 10, 5};
        int missing2 = findMissingNumber(arr2);
        System.out.println("Missing number in arr2: " + missing2);
    }

    public static int findMissingNumber(int[] arr) {
        int n = arr.length + 1; // Длина массива должна быть n-1, поэтому нам нужно добавить 1.
        int totalSum = n * (n + 1) / 2; // Сумма всех чисел от 1 до n по формуле арифметической прогрессии.
        int arrSum = 0;

        for (int num : arr) {
            arrSum += num;
        }

        return totalSum - arrSum;
    }
}









