package de.telran.hometask13;

public class SQLQueryBuilder {
    public static void main(String[] args) {
        String[] data = {"model", "V-60", "country", "Germany", "city", "Berlin", "year", null, "active", String.valueOf(true)};
        String tableName = "cars";
        StringBuilder query = buildSQLQuery(tableName, data);
        System.out.println(query.toString());
    }

    public static StringBuilder buildSQLQuery(String tableName, String[] data) {
        StringBuilder query = new StringBuilder("SELECT * FROM " + tableName + " WHERE ");
        boolean isFirstCondition = true;

        for (int i = 0; i < data.length; i += 2) {
            String columnName = data[i];
            Object columnValue = data[i + 1];

            if (columnValue != null) {
                if (!isFirstCondition) {
                    query.append(" AND ");
                }
                query.append(columnName).append(" = '").append(columnValue).append("'");
                isFirstCondition = false;
            }
        }

        return query;
    }
}




