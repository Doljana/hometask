package de.telran.hometask6;

public class Task2 {
    public static void main(String[] args) {

        int a =44 , b = 33;

        System.out.println(sum(a, b));
        System.out.println(subtraction(a, b));
        System.out.println(multiplication(a, b));
        System.out.println(division(a, b));
    }

    static int sum(int a, int b) {
        return a + b;
    }

    static int subtraction(int a, int b) {
        return a - b;
    }

    static int multiplication(int a, int b) {
        return a * b;
    }

    static int division(int a, int b) {
        return a / b;
    }

}
    //Реализовать программу, выводящую на экран результаты:
      //  Сложения двух чисел
        //Вычитания двух чисел
        //Умножения двух чисел
        //Деления двух чисел
        //Каждая из арифметических операций должна быть реализована как отдельный метод.

