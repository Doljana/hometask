package de.telran.hometask10;

public class GroceryShopping {
    public static void main(String[] args) {

        boolean isEdekaOpen = true;
        boolean isReweOpen = false;
        boolean canBuy = canBuyFood(isEdekaOpen, isReweOpen);

        String result = canBuy ? "Я могу купить еду, это правда." : "Я не могу купить еду, это неправда.";
        System.out.println(result);
    }


        public static boolean canBuyFood(boolean isEdekaOpen, boolean isReweOpen)
        {           return isEdekaOpen || isReweOpen;
}
}
