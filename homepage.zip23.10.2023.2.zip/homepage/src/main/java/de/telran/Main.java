package de.telran;


public class Main {

    public static void main(String[] args) {
        String str1 = "I study Basic Java";
        String strCopy = str1;



        str1 = str1 + " Java.";


        System.out.println(strCopy);

        System.out.println("Длина str1 = "+str1.length());

        char symbol = str1.charAt(0);
        symbol = str1.charAt(str1.length()-3);
        System.out.println("Предпоследний символ str1 = "+ symbol);

        String subStr = str1.substring(14);


        subStr = str1.substring(14, 19);
        System.out.println("Подстрока str1 = "+ subStr);

        System.out.println("str1 содежит ли подстроку Java = "+ str1.contains ("Java"));


        System.out.println(subStr.toUpperCase());
        System.out.println(str1.toLowerCase());





        int arg1 = 88, arg2 =19;

        int sum= arg1 + arg2 ;
        int dif = arg1 - arg2;
        int mult = arg1 * arg2;
        int div = arg1 / arg2;
        int ost = arg1 % arg2;

        System.out.println("arg1 + arg2 = "+sum);
        System.out.println("arg1 - arg2 = "+dif);
        System.out.println("arg1 * arg2 = "+mult);
        System.out.println("arg1 / arg2 = "+div);






}

    }













   // Создайте строку через new - I study Basic Java!
//Распечатать пред-последний символ строки. Используем метод String.charAt().
//Проверить, содержит ли ваша строка подстроку “Java”. Используем метод String.contains().
//Вырезать строку Java c помощью метода String.substring().
//Заменить все символы “а” на “о”.
//Преобразуйте строку к верхнему регистру.
//Преобразуйте строку к нижнему регистру.


    //Создайте методы с математическими операциями +, -, *, /
      //  Каждый метод принимает два числа в параметрах и возвращает результат
        //Вызовите все методы в main
        //Результат распечатайте в консоль

