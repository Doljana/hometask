package de.telran.hometask6;

import java.util.Scanner;

public class Konverter {
   // Программа запрашивает у пользователя сумму в Евро для конвертации
    //Реализовать метод, который конвертирует полученную сумму в сумму в долларах США
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите колличество Евро для конвертации");
        int numberSystem = scanner.nextInt();
       exchange(numberSystem);
    }

static void exchange (int euro){
        double dollars = 1.06;
    System.out.println(" Результат конвертации в долларах:  " + euro*dollars +" $");

}



}

