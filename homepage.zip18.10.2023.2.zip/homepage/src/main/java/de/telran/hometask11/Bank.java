package de.telran.hometask11;

public class Bank {
    public static void main(String[] args) {
   int N = 21;
        int days = withdrawAllMoney(N);

        System.out.println("Для снятия всех денег понадобится " + days + " дней.");
    }

    public static int withdrawAllMoney(int N) {
        int days = 0;

        while (N > 0) {
            int maxWithdrawal = 1;
            for (int i = 1; i <= N; i++) {
                if (N % i == 0 && i < N) {
                    maxWithdrawal = i;
                }
            }
            N -= maxWithdrawal;
            days++;
        }

        return days;
    }
}


