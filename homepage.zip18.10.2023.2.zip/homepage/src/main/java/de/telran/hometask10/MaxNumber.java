package de.telran.hometask10;

import java.util.Scanner;

public class MaxNumber {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        int num1= scanner.nextInt();
        int num2= scanner.nextInt();
        int num3= scanner.nextInt();

        System.out.println("Введите первое целое число :" +num1);
        System.out.println("Введите первое целое число :"+ num2);
        System.out.println("Введите первое целое число :" +num3);
        int max = getMax(num1, num2, num3);

        System.out.println("Максимальное число из " + num1 + ", " + num2 + " и " + num3 + " - это " + max);

    }

    public static int getMax(int a, int b, int c) {
        int max = a;

        if (b > max) {
            max = b;
        }

        if (c > max) {
            max = c;
        }

        return max;
    }



}


    //Реализуйте программу, которая попросит пользователя ввести три целых числа (используйте сканер).
// Напишите метод getMax, который принимает эти 3 параметра и возвращает наибольший из них.
       // Напечатает максимум из трех чисел.

