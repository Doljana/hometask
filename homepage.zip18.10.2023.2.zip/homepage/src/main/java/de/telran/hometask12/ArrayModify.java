package de.telran.hometask12;

import java.util.Random;

public class ArrayModify {
    public static void main(String[] args) {
        int[] array = new int[8];
        Random random = new Random();

        // Заполняем массив случайными целыми числами из интервала [1;50]
        for (int i = 0; i < array.length; i++) {
            array[i] = random.nextInt(50) + 1;
        }

        // Выводим исходный массив на консоль в строку
        System.out.print("Исходный массив: ");
        for (int number : array) {
            System.out.print(number + " ");
        }
        System.out.println();

        // Заменяем каждый элемент с нечетным индексом на ноль
        for (int i = 1; i < array.length; i += 2) {
            array[i] = 0;
        }

        // Выводим модифицированный массив на консоль в отдельной строке
        System.out.print("Модифицированный массив: ");
        for (int number : array) {
            System.out.print(number + " ");
        }
    }
}


