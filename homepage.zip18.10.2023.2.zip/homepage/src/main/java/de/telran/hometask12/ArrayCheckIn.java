package de.telran.hometask12;

import java.util.Random;

public class ArrayCheckIn {
    public static void main(String[] args) {
        //Создайте массив из 5 случайных целых чисел из интервала [10;99]
        //Выведите его на консоль в строку.
        //Определите и выведите на экран сообщение о том, является ли массив строго возрастающей последовательностью.
        int[] array = new int[5];
        Random random = new Random();

        // Заполняем массив случайными целыми числами из интервала [10;99]
        for (int i = 0; i < array.length; i++) {
            array[i] = random.nextInt(90) + 10; 
        }

        // Выводим массив на консоль в строку
        System.out.print("Массив: ");
        for (int number : array) {
            System.out.print(number + " ");
        }
        System.out.println();

        // Проверяем, является ли массив строго возрастающей последовательностью
        boolean isIncreasing = true;
        for (int i = 1; i < array.length; i++) {
            if (array[i] <= array[i - 1]) {
                isIncreasing = false;
                break;
            }
        }

        if (isIncreasing) {
            System.out.println("Массив является строго возрастающей последовательностью.");
        } else {
            System.out.println("Массив не является строго возрастающей последовательностью.");
        }
    }
}








